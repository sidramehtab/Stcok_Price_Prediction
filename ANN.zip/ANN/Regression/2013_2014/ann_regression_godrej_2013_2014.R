# ANN Regression Godrej Training 2013 Test 2014 #

set.seed(200)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
godrej_2014_reg <- read.csv("godrej_2014_reg.csv")

str(godrej_2013_reg)
str(godrej_2014_reg)

normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
}

godrej_2013_reg_norm <- as.data.frame(lapply(godrej_2013_reg, normalize))
godrej_2014_reg_norm <- as.data.frame(lapply(godrej_2014_reg, normalize))
summary(godrej_2013_reg_norm$open_perc)
summary(godrej_2014_reg_norm$open_perc)

library(neuralnet)
head(godrej_2013_reg_norm)
head(godrej_2014_reg_norm)

godrej_2013_reg_model <- neuralnet(open_perc ~ month + day_month + day_week + time + high_perc + low_perc + close_perc + close_perc + vol_perc + nifty_perc + range_diff, stepmax = 1e6, linear.output=TRUE, hidden=1, data = godrej_2013_reg_norm)
plot(godrej_2013_reg_model, lwd=2)
model_results <- compute(godrej_2013_reg_model, godrej_2014_reg_norm[c(1:4,6:11)])
predicted_perc_norm <- model_results$net.result
predicted_perc <- predicted_perc_norm*(max(godrej_2014_reg$open_perc) - min(godrej_2014_reg$open_perc)) + min(godrej_2014_reg$open_perc)
predicted_perc

plot(godrej_2014_reg$open_perc, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", type = 'l', lwd = 2)
lines(predicted_perc, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

r <- (godrej_2014_reg$open_perc - predicted_perc)
plot(r, xlab = "Time points", ylab = "Residual values", lwd = 2)

attach(godrej_2014_reg)
plot(predicted_perc~godrej_2014_reg$open_perc, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)

cor(predicted_perc, godrej_2014_reg$open_perc)

library(Metrics)
 x<- rmse(predicted_perc, godrej_2014_reg$open_perc)
 x
 y <- mean(abs(godrej_2014_reg$open_perc))
 y
 (x/y)*100
 
 w = predicted_perc * godrej_2014_reg$open_perc
 l <- which (w < 0)
 length(l)
 