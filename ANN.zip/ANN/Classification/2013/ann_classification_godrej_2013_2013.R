# ANN Godrej Classification Model 2013 Data 2013 #

godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
str(godrej_2013_cls)
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
}

godrej_2013_cls_norm <- as.data.frame(lapply(godrej_2013_cls, normalize))
summary(godrej_2013_cls_norm$open_perc)

library(neuralnet)
head(godrej_2013_cls_norm)
godrej_2013_cls_model <- neuralnet(open_perc ~ ., data = godrej_2013_cls_norm, hidden=1, linear.output = FALSE,stepmax = 1e6)
plot(godrej_2013_cls_model)
model_results <- compute(godrej_2013_cls_model, godrej_2013_cls_norm[c(1:4,6:11)])
predicted_perc <- model_results$net.result
plot(godrej_2013_cls$open_perc~predicted_perc, xlab = "Predicted percentage change in Open value", ylab = "Actual percentage change in Open value", lwd = 2)
gg <- floor(predicted_perc + 0.5)
gg
ttt=table(godrej_2013_cls$open_perc,gg)
ttt
error=(ttt[1,2]+ttt[2,1])/745
error
z <- abs(godrej_2013_cls$open_perc - gg)
which(z > 0)
