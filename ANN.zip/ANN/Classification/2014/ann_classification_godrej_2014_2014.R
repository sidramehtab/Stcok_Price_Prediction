# ANN Classification Godrej Training 2014 Test 2014 #
set.seed(300)
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
str(godrej_2014_cls)

normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
}

godrej_2014_cls_norm <- as.data.frame(lapply(godrej_2014_cls, normalize))
summary(godrej_2014_cls_norm$open_perc)

library(neuralnet)
head(godrej_2014_cls_norm)
# increase the threshold values from 01. to 0.2 to 0.3 and so on if there is any issues related to convergence.
# increase stepmax to 1e6 to 1e7 to 1e8 and so on. However, it exponentially increases the computation time. 
godrej_2014_cls_model <- neuralnet(open_perc ~ month + day_month + day_week + time + high_perc + low_perc + close_perc + vol_perc + nifty_perc + range_diff, data = godrej_2014_cls_norm, threshold = 0.2, linear.output= FALSE, stepmax = 1e7)
plot(godrej_2014_cls_model)
model_results <- compute(godrej_2014_cls_model, godrej_2014_cls_norm[c(1:4,6:11)])
predicted_perc <- model_results$net.result

plot(godrej_2014_cls$open_perc~predicted_perc, xlab = "Predicted percentage change in Open value", ylab = "Actual percentage change in Open value", lwd = 2)
gg <- floor(predicted_perc + 0.5)
gg

ttt <- table(godrej_2014_cls$open_perc, gg)
ttt

error <- (ttt[1,2] + ttt[2,1])/725
error

z <- abs(godrej_2014_cls$open_perc - gg)
which (z > 0)
