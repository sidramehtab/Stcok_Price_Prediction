# ANN Classification Model Godrej Training 2013 Test 2014 #

set.seed(300)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")

str(godrej_2013_cls)
str(godrej_2014_cls)
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))
}
godrej_2013_cls_norm <- as.data.frame(lapply(godrej_2013_cls, normalize))
godrej_2014_cls_norm <- as.data.frame(lapply(godrej_2014_cls, normalize))
summary(godrej_2013_cls_norm$open_perc)
summary(godrej_2014_cls_norm$open_perc)

library(neuralnet)
head(godrej_2014_cls_norm)

godrej_2013_cls_model <- neuralnet(open_perc ~ month + day_month + day_week + time + high_perc + low_perc + close_perc + vol_perc + nifty_perc + range_diff, data = godrej_2013_cls_norm,hidden = 1, linear.output=FALSE)
plot(godrej_2013_cls_model)
model_results <- compute(godrej_2013_cls_model, godrej_2014_cls_norm[c(1:4,6:11)])
predicted_perc <- model_results$net.result
predicted_perc 
plot(godrej_2014_cls$open_perc~predicted_perc, xlab = "Predicted percentage change in Open value", ylab = "Actual percentage change in Open value", lwd = 2)
gg <- floor(predicted_perc + 0.5)
gg
ttt <- table(godrej_2014_cls$open_perc, gg)
ttt

error <- 100*(ttt[1,2] +ttt[2,1])/725
error

z <- abs(godrej_2014_cls$open_perc - gg)
which(z > 0)
