# Multivariate Regression Godrej Training 2013 Test 2013 #

##############################################
#   Backward Removal Procedure               #
##############################################

godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
head(godrej_2013_reg)
library(faraway)
godrej_2013_reg.lm <- lm(open_perc ~. ,data = godrej_2013_reg)
vif(godrej_2013_reg.lm)
# Multicollinear variables are: high_perc & low_perc, close_perc & range_diff. 
# We keep low_perc and range_diff and leave out the other two out. 
godrej_2013_reg.lm <- lm(open_perc~month+day_month+day_week+time+low_perc+vol_perc+range_diff+nifty_perc, data=godrej_2013_reg)
vif(godrej_2013_reg.lm)
formula(godrej_2013_reg.lm)
drop1(godrej_2013_reg.lm,test='F')

# five variables have lowest AIC: month,day_month, day_week, vol_perc, nifty_perc and none of them have 
# significant p-values
# it is removed. 

godrej_2013_reg.lm <- lm(open_perc~time+low_perc+range_diff, data=godrej_2013_reg)
formula(godrej_2013_reg.lm)
drop1(godrej_2013_reg.lm, test='F')
# time has the lowest AIC of -3662.3 with a p-value of 0.6494. Hence it is removed,
godrej_2013_reg.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2013_reg)
formula(godrej_2013_reg.lm)
drop1(godrej_2013_reg.lm, test='F')
# no more variables can be dropped.
summary(godrej_2013_reg.lm)
predict(godrej_2013_reg.lm)
godrej_2013_reg.lm$residuals
plot(godrej_2013_reg.lm$residuals, xlab = "Time points", ylab = "Residual values", lwd =2, xlim = c(0, 800))

######################################################
#         Forward Addition Procedure                 #
######################################################

godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
head(godrej_2013_reg)
godrej_2013_reg <- godrej_2013_reg[,-6] # Multicollinear variable high_perc removed
head(godrej_2013_reg)
godrej_2013_reg <- godrej_2013_reg[,-7] # Multicollinear variable close_perc removed
head(godrej_2013_reg)
godrej_2013_reg.lm<- lm(open_perc~1, data=godrej_2013_reg)
summary(godrej_2013_reg.lm)
add1(godrej_2013_reg.lm, scope=godrej_2013_reg)
# low_perc has the lowest AIC value of -3082.08, hence it is included in the model.
godrej_2013.lm<- lm(open_perc~low_perc, data=godrej_2013_reg)
summary(godrej_2013.lm)
add1(godrej_2013.lm, scope=godrej_2013_reg)
# range_diff has the lowest AIC of -3662.3, hence it is included in the model.
godrej_2013.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2013_reg)
summary(godrej_2013.lm)
add1(godrej_2013.lm, scope=godrej_2013_reg)
# times has the lowest AIC(-3660.5) and hence it is included in the model.
godrej_2013.lm <- lm(open_perc~low_perc+range_diff+time, data=godrej_2013_reg)
summary(godrej_2013.lm)
# We find time is not significant. Hence, it cannot be added to the model.
# Hence the final model is:
godrej_2013.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2013_reg)
summary(godrej_2013.lm)
predict(godrej_2013.lm)  

###########################################################################################
# Computation of correlation coefficient between predicted and actual values of open_perc #
###########################################################################################

actual <- scan("actual.txt")
predicted <- scan("predicted.txt")
plot(actual, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", type = 'l', lwd = 2)
lines(predicted, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

attach(godrej_2013_reg)
plot(predicted~actual, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)




# Computation of RMSE value #
cor(actual, predicted)
cor.test(actual, predicted)
library(Metrics)
x <- rmse(actual, predicted)   
x
actual <- abs(actual)
y <- mean(actual) 
y
(x/y)*100       

actual <- scan("actual.txt")
predicted <- scan("predicted.txt")
w <- predicted*actual
n3 <- which(w<0)
n3
length(n3)


###########################################
# BP Test for Checking Heteroscedasticity #
#######################
####################
library(lmtest)
godrej_2013_reg.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2013_reg)
plot(godrej_2013_reg.lm$residuals, xlab = "Time points", ylab = "Residual values", lwd =2, xlim = c(0, 800))
bptest(godrej_2013_reg.lm, data = godrej_2013_reg)
# p-value of null hypothesis is 0.005978 which is not significant. This indicates that the
# errors are not homoscedastic.

##########################################
# Durbin-Watson Test for Autocorrelation #
##########################################
library(lmtest)
godrej_2013_reg.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2013_reg)
plot(godrej_2013_reg.lm$residuals, xlab = "Time points", ylab = "Residual values", lwd =2, xlim = c(0, 800))
dwtest(open_perc~low_perc+range_diff, data=godrej_2013_reg)
# Null Hypothesis that presumes that there is no autocorrelation has a support of 
# p-value of 1. Hence the Null Hypothesis is not rejected. Errors dont exhibit any
# autocorrelation.

