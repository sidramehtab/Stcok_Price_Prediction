# Multivariate Regression Godrej Training 2014 Test 2014 #

##############################################
#   Backward Removal Procedure               #
##############################################

godrej_2014_reg <- read.csv("godrej_2014_reg.csv")
head(godrej_2014_reg)
library(faraway)
godrej_2014_reg.lm <- lm(open_perc ~. ,data = godrej_2014_reg)
vif(godrej_2014_reg.lm)
# Multicollinear variables are: high_perc, low_perc, close_perc, range_diff. 
# We keep low_perc and range_diff and leave out the other two out. 
godrej_2014_reg.lm <- lm(open_perc~month+day_month+day_week+time+low_perc+vol_perc+range_diff+nifty_perc, data=godrej_2014_reg)
formula(godrej_2014_reg.lm)
drop1(godrej_2014_reg.lm,test='F')
# day_week has the lowest AIC(-2515.96) and its p value is 0.9507 which is not significant.
# Hence it is removed.
godrej_2014_reg.lm <- lm(open_perc~month+day_month+time+low_perc+vol_perc+range_diff+nifty_perc, data=godrej_2014_reg)
formula(godrej_2014_reg.lm)
drop1(godrej_2014_reg.lm, test='F')
# month has the lowest AIC (-2517.88) and its p-value is 0.7740 which is not significant.
# Hence it is removed.
godrej_2014_reg.lm <- lm(open_perc~day_month+time+low_perc+vol_perc+range_diff+nifty_perc, data=godrej_2014_reg)
drop1(godrej_2014_reg.lm, test='F')
# day_month has the lowest AIC (-2519.19) and its p-value is 0.4077 which is not significant.
#Hence it is removed.
godrej_2014_reg.lm <- lm(open_perc~time+low_perc+vol_perc+range_diff+nifty_perc, data=godrej_2014_reg)
formula(godrej_2014_reg.lm)
drop1(godrej_2014_reg.lm, test='F')
# time has the lowest AIC (-2520.48) and its p-value is 0.4024 which is not significant.
# Hence, it is dropped.
godrej_2014_reg.lm <- lm(open_perc~low_perc+vol_perc+range_diff+ nifty_perc, data=godrej_2014_reg)
formula(godrej_2014_reg.lm)
drop1(godrej_2014_reg.lm, test='F')
# vol_perc has the lowest AIC (-2521.27) and its p-value is 0.2729, which is not significant.
# Hence, it is removed.
godrej_2014_reg.lm <- lm(open_perc~low_perc+range_diff+nifty_perc, data=godrej_2014_reg)
formula(godrej_2014_reg.lm)
drop1(godrej_2014_reg.lm, test='F')
# nifty_perc has the lowest AIC (-2521.8) and its p-value is 0.2354. Hence it is removed.
godrej_2014_reg.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2014_reg)
formula(godrej_2014_reg.lm)
drop1(godrej_2014_reg.lm, test='F')
# None of the two variables can be removed. 
summary(godrej_2014_reg.lm)
godrej_2014_reg.lm$residuals
plot(godrej_2014_reg.lm$residuals, xlab = "Time points", ylab = "Residual values", lwd =2, xlim = c(0, 800))

######################################################
#         Forward Addition Procedure                 #
######################################################

godrej_2014_reg <- read.csv("godrej_2014_reg.csv")
head(godrej_2014_reg)
godrej_2014_reg <- godrej_2014_reg[,-6] # Multicollinear varibale high_perc removed
head(godrej_2014_reg)
godrej_2014_reg <- godrej_2014_reg[,-7] # Multicollinear variable close_perc removed
head(godrej_2014_reg)
godrej_2014_reg.lm<- lm(open_perc~1, data=godrej_2014_reg)
summary(godrej_2014_reg.lm)
add1(godrej_2014_reg.lm, scope=godrej_2014_reg)
# low_perc has the lowest AIC value of 1974.69 hence it is included in the model.
godrej_2014.lm<- lm(open_perc~low_perc, data=godrej_2014_reg)
summary(godrej_2014.lm)
add1(godrej_2014.lm, scope=godrej_2014_reg)
# range_diff has the lowest AIC of -2521.8, hence it is included in the model.
godrej_2014.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2014_reg)
summary(godrej_2014.lm)
add1(godrej_2014.lm, scope=godrej_2014_reg)
# nifty_perc has the lowest AIC(-2521.3) and hence it is included in the model.
godrej_2014.lm <- lm(open_perc~low_perc+range_diff+nifty_perc, data=godrej_2014_reg)
summary(godrej_2014.lm)
# We find nifty_perc is not significant. Hence, it cannot be added to the model.
# Hence the final model is:
godrej_2014.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2014_reg)
summary(godrej_2014.lm)
predict(godrej_2014.lm)  

###########################################################################################
# Computation of correlation coefficient between predicted and actual values of open_perc #
###########################################################################################

actual <- scan("actual.txt")
predicted <- scan("predicted.txt")
plot(actual, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", type = 'l', lwd = 2)
lines(predicted, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

attach(godrej_2014_reg)
plot(predicted~actual, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)


# Computation of RMSE value #
cor(actual, predicted)
cor.test(actual, predicted)
library(Metrics)
x <- rmse(actual, predicted)   
x
actual <- abs(actual)
y <- mean(actual)  
y
(x/y)*100       

actual <- scan("actual.txt")
predicted <- scan("predicted.txt")
w <- predicted*actual
n4 <- which(w<0)
n4
length(n4)
###########################################
# BP Test for Checking Heteroscedasticity #
###########################################
library(lmtest)
godrej_2014_reg.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2014_reg)
plot(godrej_2014_reg.lm$residuals, xlab = "Time points", ylab = "Residual values", lwd =2, xlim = c(0, 800))
bptest(godrej_2014_reg.lm, data = godrej_2014_reg)
# p-value of null hypothesis is 0.231 which is not significant. This indicates that the
# errors are homoscedastic.

##########################################
# Durbin-Watson Test for Autocorrelation #
##########################################
library(lmtest)
godrej_2014_reg.lm <- lm(open_perc~low_perc+range_diff, data=godrej_2014_reg)
plot(godrej_2014_reg.lm$residuals, xlab = "Time points", ylab = "Residual values", lwd =2, xlim = c(0, 800))
dwtest(open_perc~low_perc+range_diff, data=godrej_2014_reg)
# Null Hypothesis that presumes that there is no autocorrelation has a support of 
# p-value of 1. Hence the Null Hypothesis is not rejected. Errors dont exhibit any
# autocorrelation.
