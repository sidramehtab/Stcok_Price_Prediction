godrej <- read.csv("Godrej.csv")
plot(godrej$open, lwd=1, lty=1, type='l')
