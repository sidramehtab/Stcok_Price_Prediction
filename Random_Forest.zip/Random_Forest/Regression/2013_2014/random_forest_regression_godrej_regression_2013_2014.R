# Random Forest Regression using Godrej Model of 2013 Data of 2014 #
# install.packages("randomForest")

library(randomForest)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
godrej_2014_reg <- read.csv("godrej_2014_reg.csv")
set.seed(300)
attach(godrej_2013_reg)
myrf <- randomForest(open_perc~.,data = godrej_2013_reg)
myrf
open_pred <- predict(myrf, godrej_2014_reg)
open_pred

plot(godrej_2014_reg$open_perc, xlab="Time points", ylab="Percentage change in Open value", lwd=2, lty=1, col="blue", type='l')
lines(open_pred, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

r <- (godrej_2014_reg$open_perc - open_pred)
plot(r, xlab = "Time points", ylab = "Residual values", lwd = 2)
attach(godrej_2014_reg)
plot(open_pred~godrej_2014_reg$open_perc,  xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)

cor(godrej_2014_reg$open_perc, open_pred)
library(Metrics)
x <- rmse(godrej_2014_reg$open_perc, open_pred)
x
y <- mean(abs(godrej_2014_reg$open_perc))
y
z <- (x/y)*100
z

predicted <- scan("predicted.txt")
actual <- scan("actual.txt")

w <- predicted*actual
length(m)

w <- godrej_2014_reg$open_perc*open_pred
m <- which (w < 0)
length(m)


