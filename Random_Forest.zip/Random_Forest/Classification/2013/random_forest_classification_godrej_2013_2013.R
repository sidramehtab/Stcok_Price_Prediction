# Random Forest using Godrej Model of 2013 Data of 2013 #
# install.packages("randomForest")

library(randomForest)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2013_cls$open_perc <- as.factor(godrej_2013_cls$open_perc)
godrej_2013_cls$open_perc
set.seed(300)
attach(godrej_2013_cls)
myrf <- randomForest(open_perc~., godrej_2013_cls)
myrf
open_pred <- predict(myrf, godrej_2013_cls)
open_pred
