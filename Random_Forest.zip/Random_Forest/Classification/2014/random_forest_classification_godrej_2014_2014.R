# Random Forest using Godrej Model of 2014 Data of 2014 #
# install.packages("randomForest")

library(randomForest)
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
godrej_2014_cls$open_perc <- factor(godrej_2014_cls$open_perc)
godrej_2014_cls$open_perc
set.seed(300)
attach(godrej_2014_cls)
myrf <- randomForest(open_perc~., godrej_2014_cls)
myrf
open_pred <- predict(myrf, godrej_2014_cls)
open_pred
