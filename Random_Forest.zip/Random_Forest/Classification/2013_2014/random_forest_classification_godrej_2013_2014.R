# Random Forest Classification using Godrej Model 2013 and Data 2014 #

library(randomForest)

godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")

godrej_2013_cls$open_perc <- factor(godrej_2013_cls$open_perc)
godrej_2014_cls$open_perc <- factor(godrej_2014_cls$open_perc)                                 
set.seed(300)
attach(godrej_2013_cls)
myrf <- randomForest(open_perc~., data=godrej_2013_cls)
myrf
open_pred <- predict(myrf, godrej_2014_cls)
open_pred
attach(godrej_2014_cls)

predicted <- scan("predicted.txt")
actual <- scan("actual.txt")
z <- (predicted -actual)

n1 <- which(z==1)
length(n1)
n2 <- which(z==-1)
length(n2)
n3 <- which(actual==0)
length(n3)
n4 <- which(actual==1)
length(n4)

