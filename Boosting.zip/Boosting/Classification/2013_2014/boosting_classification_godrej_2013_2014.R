# Boosting Classification Godrej Model 2013 Data 2014 #

library(adabag)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
set.seed(300)
godrej_2013_cls$open_perc <- as.factor(godrej_2013_cls$open_perc)
godrej_2013_cls <- godrej_2013_cls[1:725,]
godrej_2014_cls$open_perc <- as.factor(godrej_2014_cls$open_perc)
attach(godrej_2013_cls)
myadaboost <- boosting(open_perc~., data=godrej_2013_cls)
godrej_2014_cls$open_perc <- as.factor(godrej_2014_cls$open_perc)
open_pred <- predict(myadaboost, godrej_2014_cls)
open_pred <- as.numeric(open_pred$class)
open_pred
predicted <- scan("predicted.txt")
actual <- scan("actual.txt")
z <- (predicted - actual)
which(z == 1 | z == -1)

attach(godrej_2014_cls)
plot(predicted~actual, xlab = "Predicted Inedx", ylab = "Actual Index", lwd = 2)

which(z==1)
