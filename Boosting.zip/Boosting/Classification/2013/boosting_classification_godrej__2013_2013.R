# Boosting Classification Godrej Model 2013 and Data 2013 #

library(adabag)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
set.seed(300)
godrej_2013_cls$open_perc <- as.factor(godrej_2013_cls$open_perc)
myadaboost <- boosting(open_perc~., data=godrej_2013_cls)
open_pred <- predict(myadaboost, godrej_2013_cls)
open_pred$class <- as.numeric(open_pred$class)
open_pred$class

attach(godrej_2013_cls)
plot(open_pred$class~godrej_2013_cls$open_perc, xlab = "Predicted Inedx", ylab = "Actual Index", lwd = 2)


open_perc <- as.numeric(godrej_2013_cls$open_perc)

c <- abs(open_perc - open_pred$class)
c
