# Boosting Classification Model Godrej Training 2014 Test 2014 #

library(adabag)
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
set.seed(300)
godrej_2014_cls$open_perc <- as.factor(godrej_2014_cls$open_perc)
myadaboost <- boosting(open_perc~., data=godrej_2014_cls)
open_pred <- predict(myadaboost, godrej_2014_cls)
open_pred$class <- as.numeric(open_pred$class)
open_pred$class

attach(godrej_2014_cls)
plot(open_pred$class~godrej_2014_cls$open_perc, xlab = "Predicted Inedx", ylab = "Actual Index", lwd = 2)


open_perc <- as.numeric(godrej_2014_cls$open_perc)

c <- abs(open_perc - open_pred$class)
c
