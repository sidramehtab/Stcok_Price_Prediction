# Boosting Regression Godrej Model 2013 and Data 2013 #
#install.packages("mboost")

library(mboost)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
set.seed(300)

myadaboost <- blackboost(open_perc ~ ., data=godrej_2013_reg)
# open_pred <- predict(myadaboost, godrej_2013_reg)
open_pred <- predict(myadaboost)
open_pred


plot(godrej_2013_reg$open_perc, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", type = 'l', lwd = 2)
lines(open_pred, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

y <- (godrej_2013_reg$open_perc - open_pred)
plot(y, xlab = "Time points", ylab = "Residual values", lwd = 3)

plot(open_pred~godrej_2013_reg$open_perc, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)

cor(godrej_2013_reg$open_perc, open_pred)
library(Metrics)

x <- rmse(godrej_2013_reg$open_perc, open_pred)
x
y <- mean(abs(godrej_2013_reg$open_perc))
y
z <- (x/y)*100
z

w <- godrej_2013_reg$open_perc * open_pred
m <- which(w < 0)
length(m)

