# KNN Classification using Godrej Model of 2013 Data of 2014 #

library(textir)
library(MASS)

godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
str(godrej_2013_cls)
str(godrej_2014_cls)
godrej_2013_cls$open_perc <- as.factor(godrej_2013_cls$open_perc)
godrej_2014_cls$open_perc <- as.factor(godrej_2014_cls$open_perc)
table(godrej_2013_cls$open_perc)
table(godrej_2014_cls$open_perc)

library(class)

godrej_2013_cls_n <- scale(godrej_2013_cls[,-5])
godrej_2014_cls_n <- scale(godrej_2014_cls[,-5])

# tata_2013_train <- tata_2013_knn_n[1:745,]
# tata_2014_test <- tata_2014_knn_n[1:725,]

nearest1 <- knn(train=godrej_2013_cls_n, test = godrej_2014_cls_n, cl = godrej_2013_cls$open_perc, k =1)
nearest3 <- knn(train=godrej_2013_cls_n, test = godrej_2014_cls_n, cl = godrej_2013_cls$open_perc, k =3)
nearest5 <- knn(train=godrej_2013_cls_n, test = godrej_2014_cls_n, cl = godrej_2013_cls$open_perc, k =5)
nearest7 <- knn(train=godrej_2013_cls_n, test = godrej_2014_cls_n, cl = godrej_2013_cls$open_perc, k =7)
nearest9 <- knn(train=godrej_2013_cls_n, test = godrej_2014_cls_n, cl = godrej_2013_cls$open_perc, k =9)

# par(mfrow=c(1,2))

# plot(tata_2013_knn_n, col=tata_2013_knn_n$open_perc, cex = 0.8, main = "1-nearest neighbor")
# points(tata_2013_knn_n, bg=nearest1, pch=21, col=grey(.9), cex = 1.25)

# plot(tata_2013_knn_n, col=tata_2013_knn_n$open_perc, cex = 0.8, main = "3-nearest neighbor")
# points(tata_2013_knn_n, bg=nearest3, pch=21, col=grey(.9), cex = 1.25)
# legend("topright", legend=levels(tata_2013_knn_n$open_perc)), fill=1:2, bty ="n", cex = .75)

# plot(tata_2013_knn_n, col=tata_2013_knn_n$open_perc, cex = 0.8, main = "5-nearest neighbor")
# points(tata_2013_knn_n, bg=nearest5, pch=21, col=grey(.9), cex = 1.25)
# legend("topright", legend=levels(tata_2013_knn_n$open_perc)), fill=1:2, bty ="n", cex = .75)

pcorrn1 <- 100*sum(godrej_2014_cls$open_perc == nearest1)/725
pcorrn3 <- 100*sum(godrej_2014_cls$open_perc == nearest3)/725
pcorrn5 <- 100*sum(godrej_2014_cls$open_perc == nearest5)/725
pcorrn7 <- 100*sum(godrej_2014_cls$open_perc == nearest7)/725
pcorrn9 <- 100*sum(godrej_2014_cls$open_perc == nearest9)/725
pcorrn1
pcorrn3
pcorrn5
pcorrn7
pcorrn9

a <- as.numeric(nearest7)
b <- as.numeric(godrej_2014_cls$open_perc)
z <- a - b
z
which(z == 1)
which(z == 0)
which(z == -1)
