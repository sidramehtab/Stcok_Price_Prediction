# KNN Classification Godrej Model 2013 Data 2013 #

godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
str(godrej_2013_cls)
table(godrej_2013_cls$open_perc)
normalize <- function(x) {return ((x-min(x))/(max(x)-min(x)))}
godrej_2013_cls_n <- as.data.frame(lapply(godrej_2013_cls, normalize))
library(class)
godrej_2013_cls_train <- godrej_2013_cls_n[1:745,-5]
godrej_2013_cls_test <- godrej_2013_cls_n[1:745,-5]
godrej_2013_cls_train_labels <- godrej_2013_cls[1:745,5]
godrej_2013_cls_test_labels <- godrej_2013_cls[1:745,5]
godrej_2013_cls_test_pred_1 <- knn(train=godrej_2013_cls_train, test = godrej_2013_cls_test, cl= godrej_2013_cls_train_labels, k=1)
godrej_2013_cls_test_pred_3 <- knn(train=godrej_2013_cls_train, test = godrej_2013_cls_test, cl= godrej_2013_cls_train_labels, k=3)
godrej_2013_cls_test_pred_5 <- knn(train=godrej_2013_cls_train, test = godrej_2013_cls_test, cl= godrej_2013_cls_train_labels, k=5)
godrej_2013_cls_test_pred_7 <- knn(train=godrej_2013_cls_train, test = godrej_2013_cls_test, cl= godrej_2013_cls_train_labels, k=7)
godrej_2013_cls_test_pred_9 <- knn(train=godrej_2013_cls_train, test = godrej_2013_cls_test, cl= godrej_2013_cls_train_labels, k=9)

nearest1 <- knn(train=godrej_2013_cls_train, test=godrej_2013_cls_test, cl=godrej_2013_cls_train_labels, k=1)
nearest1

nearest3 <- knn(train=godrej_2013_cls_train, test=godrej_2013_cls_test, cl=godrej_2013_cls_train_labels, k=3)
nearest3

nearest5 <- knn(train=godrej_2013_cls_train, test=godrej_2013_cls_test, cl=godrej_2013_cls_train_labels, k=5)
nearest5

nearest7 <- knn(train=godrej_2013_cls_train, test=godrej_2013_cls_test, cl=godrej_2013_cls_train_labels, k=7)
nearst7

nearest9 <- knn(train=godrej_2013_cls_train, test=godrej_2013_cls_test, cl=godrej_2013_cls_train_labels, k=9)
nearest9

error1 <- 100*sum(godrej_2013_cls_test_labels==nearest1)/745
error1

error3 <- 100*sum(godrej_2013_cls_test_labels==nearest3)/745
error3

error5 <- 100*sum(godrej_2013_cls_test_labels==nearest5)/745
error5

error7 <- 100*sum(godrej_2013_cls_test_labels==nearest7)/745
error7

error9 <- 100*sum(godrej_2013_cls_test_labels==nearest9)/745
error9


#install.packages("gmodels")
library(gmodels)
CrossTable(x=godrej_2013_cls_test_labels, y = godrej_2013_cls_test_pred_1, prop.chisq=FALSE)
CrossTable(x=godrej_2013_cls_test_labels, y = godrej_2013_cls_test_pred_3, prop.chisq=FALSE)
CrossTable(x=godrej_2013_cls_test_labels, y = godrej_2013_cls_test_pred_5, prop.chisq=FALSE)
CrossTable(x=godrej_2013_cls_test_labels, y = godrej_2013_cls_test_pred_7, prop.chisq=FALSE)
CrossTable(x=godrej_2013_cls_test_labels, y = godrej_2013_cls_test_pred_9, prop.chisq=FALSE)

