# KNN using Godrej Model of 2014 Data of 2014 #

library(textir)
library(MASS)
library(normalr)

godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
str(godrej_2014_cls)
godrej_2014_cls$open_perc <- as.factor(godrej_2014_cls$open_perc)
table(godrej_2014_cls$open_perc)

library(class)

godrej_2014_cls_n <- scale(godrej_2014_cls[,-5])

# tata_2014_train <- tata_2014_knn_n[1:745,]
# tata_2014_test <- tata_2014_knn_n[1:725,]

nearest1 <- knn(train=godrej_2014_cls_n, test = godrej_2014_cls_n, cl = godrej_2014_cls$open_perc, k =1)
nearest3 <- knn(train=godrej_2014_cls_n, test = godrej_2014_cls_n, cl = godrej_2014_cls$open_perc, k =3)
nearest5 <- knn(train=godrej_2014_cls_n, test = godrej_2014_cls_n, cl = godrej_2014_cls$open_perc, k =5)
nearest7 <- knn(train=godrej_2014_cls_n, test = godrej_2014_cls_n, cl = godrej_2014_cls$open_perc, k =7)
nearest9 <- knn(train=godrej_2014_cls_n, test = godrej_2014_cls_n, cl = godrej_2014_cls$open_perc, k =9)

pcorrn1 <- 100*sum(godrej_2014_cls$open_perc == nearest1)/745
pcorrn3 <- 100*sum(godrej_2014_cls$open_perc == nearest3)/745
pcorrn5 <- 100*sum(godrej_2014_cls$open_perc == nearest5)/745
pcorrn7 <- 100*sum(godrej_2014_cls$open_perc == nearest7)/745
pcorrn9 <- 100*sum(godrej_2014_cls$open_perc == nearest9)/745
pcorrn1
pcorrn3
pcorrn5
pcorrn7
pcorrn9

a <- as.numeric(nearest3)
b <- as.numeric(godrej_2013_cls$open_perc)
z <- a - b
z
which(z == 1)
which(z == 0)
which(z == -1)
