# Decision Tree Regression Godrej Model 2013 Data 2013 #

library(tree)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv", header=T)
godrej_2013_reg_tree <- tree(open_perc~., data=godrej_2013_reg, mincut=1)
plot(godrej_2013_reg_tree, lwd=3)
text(godrej_2013_reg_tree, digits=2)
# x <- predict(godrej_2013_reg_tree, data=godrej_2013_reg)
x <- predict(godrej_2013_reg_tree)
x
y <- godrej_2013_reg$open_perc
y

plot(y, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", type = 'l', lwd = 2, ylim = c(-6, 6))
lines(x, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

m <- y - x
plot(m, xlab = "Time points", ylab = "Residual values", lwd = 2)

# plot(y~x)
plot(x~y, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)

cor(x,y)
cor.test(x,y)

library(Metrics)
z <- rmse(x,y)
z
w <- mean(abs(godrej_2013_reg$open_perc))
w
(z/w)*100


#x <- scan("predicted.txt")
# y <- scan("actual.txt")
l <- x*y
k <- which(l<0)
length(k)
