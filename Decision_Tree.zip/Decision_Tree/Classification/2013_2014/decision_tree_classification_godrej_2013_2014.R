# Decision Tree Classification Godrej Model 2013 Data 2014 #

library(tree)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv", header= T)
godrej_2014_cls <- read.csv("godrej_2014_cls.csv", header=T)
godrej_2013_cls$open_perc <- as.factor(godrej_2013_cls$open_perc)
godrej_2014_cls$open_perc <- as.factor(godrej_2014_cls$open_perc)
godrej_2013_cls_tree <- tree(open_perc~., data=godrej_2013_cls, mincut=1)
godrej_2013_cls_tree
plot(godrej_2013_cls_tree,lwd =3)
text(godrej_2013_cls_tree, digits=2)
table(actual = godrej_2014_cls$open_perc, predicted = predict(godrej_2013_cls_tree, newdata = godrej_2014_cls, type = "class"))
