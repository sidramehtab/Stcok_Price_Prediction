# Logistic Regression Classification Godrej Model 2013 Data 2013

godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2013_cls_logit <- glm(open_perc~., family=binomial, data= godrej_2013_cls)
ptest <- predict(godrej_2013_cls_logit,newdata=data.frame(godrej_2013_cls),type="response")
ptest

attach(godrej_2013_cls)
plot(godrej_2013_cls$open_perc~ptest)
gg1=floor(ptest+0.5)
ttt=table(open_perc,gg1)
ttt
error=(ttt[1,2]+ttt[2,1])/725
error

# Computation of Lift
data.frame(godrej_2013_cls$open_perc, ptest)
bb <- cbind(ptest, godrej_2013_cls$open_perc)
bb[1:10,]
bb1 <- bb[order(ptest, decreasing = TRUE),]
xbar <- mean(godrej_2013_cls$open_perc)
axis <- 725
ax <- 725
ay <- 725
axis[1] = 1
ax[1] = xbar
ay[1] <- bb1[1, 2]
for( i in 2:725){
  axis[i] = i
  ax[i] = xbar*i
  ay[i] = ay[i-1]+ bb1[i,2]
}
aaa <- cbind(bb1[,1], bb1[,2], ay, ax)
plot(axis, ay, xlab="Number of Time Slots", ylab="Number of Time Slots with Gain")
points(axis,ax,type="l")

library(ROCR)
ROCRpred <- prediction(ptest, godrej_2013_cls$open_perc)
ROCRperf <- performance(ROCRpred, 'tpr','fpr')
plot(ROCRperf, colorize = TRUE, text.adj = c(-0.2,1.7), lwd = 2)

library(pROC)
roc_obj <- roc(godrej_2013_cls$open_perc, ptest)
auc(roc_obj) 
