# Support Vector Machine Classification Godrej Model of 2013 Data of 2013 #
# install.packages("kernlab")

library(kernlab)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2013_cls$open_perc <- factor(godrej_2013_cls$open_perc)
godrej_2013_cls$open_perc

# set.seed(300)
attach(godrej_2013_cls)
open_classifier <- ksvm(open_perc~., data= godrej_2013_cls, kernel="vanilladot")
open_classifier
open_pred <- predict(open_classifier, godrej_2013_cls)
open_pred
ttt <- table(open_pred, godrej_2013_cls$open_perc)
ttt
error <- (ttt[1,2]+ttt[2,1])/745
error
