# Support Vector Machine Classification Godrej Model of 2013 Data of 2014 #
# install.packages("kernlab")

library(kernlab)
godrej_2013_cls <- read.csv("godrej_2013_cls.csv")
godrej_2013_cls <- godrej_2013_cls[1:725,]
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
godrej_2013_cls$open_perc <- factor(godrej_2013_cls$open_perc)
godrej_2013_cls$open_perc

attach(godrej_2013_cls)
open_classifier <- ksvm(open_perc~., data= godrej_2013_cls, kernel="vanilladot")
open_classifier
open_pred <- predict(open_classifier, godrej_2014_cls)
open_pred
attach(godrej_2014_cls)
ttt <- table(open_pred, godrej_2014_cls$open_perc)
ttt
error <- (ttt[1,2]+ttt[2,1])/725
error
#actual <- scan("actual_class_open_perc_2013_2014.txt")
#predicted <- scan("predicted_class_open_perc_2013_2014.txt")
#z <- (predicted - actual)
#which(z==1 | z==-1)
#which(z==1)
#which(z==-1)
