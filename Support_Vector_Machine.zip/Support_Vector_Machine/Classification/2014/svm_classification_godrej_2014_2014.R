# Support Vector Machine Classification Godrej Model of 2014 Data of 2014 #
# install.packages("kernlab")

library(kernlab)
godrej_2014_cls <- read.csv("godrej_2014_cls.csv")
godrej_2014_cls$open_perc <- factor(godrej_2014_cls$open_perc)
godrej_2014_cls$open_perc

# set.seed(300)
attach(godrej_2014_cls)
open_classifier <- ksvm(open_perc~., data= godrej_2014_cls, kernel="vanilladot")
open_classifier
open_pred <- predict(open_classifier, godrej_2014_cls)
open_pred
ttt <- table(open_pred, godrej_2014_cls$open_perc)
ttt
error <- (ttt[1,2]+ttt[2,1])/725
error
