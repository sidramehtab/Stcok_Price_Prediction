# Support Vector Machine Regression Godrej Model of 2013 Data 2013 #

# install.packages("e1071")

library(e1071)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
attach(godrej_2013_reg)
godrej_2013_svm_reg <- svm(open_perc ~.,data = godrej_2013_reg, scale = TRUE)
godrej_2013_svm_reg
open_pred <- predict(godrej_2013_svm_reg, godrej_2013_reg)
open_pred
plot(godrej_2013_reg$open_perc, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", type = 'l', lwd = 2)
# plot(godrej_2013_reg$open_perc, xlab="Time points", ylab="Percentage change in Open value",lty=1, col = "blue", lwd = 2)
lines(open_pred, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
y <- (godrej_2013_reg$open_perc - open_pred)
plot(y, xlab = "Time points", ylab = "Residual values", lwd = 2)
open_pred
cor(godrej_2013_reg$open_perc, open_pred)
attach(godrej_2013_reg)
plot(open_pred~godrej_2013_reg$open_perc, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2 )
library(Metrics)
x <- rmse(godrej_2013_reg$open_perc, open_pred)
x
y <- mean(abs(godrej_2013_reg$open_perc))
y
z <- (x/y)*100
z


predicted <- scan("predicted.txt")
actual <- scan("actual.txt")
w <- predicted*actual
m <- which(w<0)
m
length(m)

w <- godrej_2013_reg$open_perc * open_pred
m <- which (w < 0)
m
length(m)


