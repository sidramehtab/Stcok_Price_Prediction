# Support Vector Machine Regression Godrej Model 2013 Data 2014 #
# install.packages("e1071")


library(e1071)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv")
godrej_2013_reg <- godrej_2013_reg[1:725,]
godrej_2014_reg <- read.csv("godrej_2014_reg.csv")

attach(godrej_2013_reg)
godrej_2013_svm_reg <- svm(open_perc ~.,data = godrej_2013_reg, scale = TRUE)
godrej_2013_svm_reg
open_pred <- predict(godrej_2013_svm_reg, godrej_2014_reg)
open_pred

plot(godrej_2014_reg$open_perc, xlab="Time points", ylab="Percentage change in Open value of Tata Steel stock",lty=1, col = "blue", type = 'l', lwd = 2, ylim = c(-6, 7))
lines(open_pred, lty=2, col = "red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

y <- (godrej_2014_reg$open_perc - open_pred)
plot(y, xlab = "Time points", ylab = "Residual values", lwd = 2)
cor(godrej_2014_reg$open_perc, open_pred)
attach(godrej_2014_reg)
plot(open_pred~godrej_2014_reg$open_perc, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)
library(Metrics)
x <- rmse(godrej_2014_reg$open_perc, open_pred)
x
y <- mean(abs(godrej_2014_reg$open_perc))
y
z <- (x/y)*100
z

w <- godrej_2014_reg$open_perc * open_pred
m <- which (w < 0)
m
length(m)
