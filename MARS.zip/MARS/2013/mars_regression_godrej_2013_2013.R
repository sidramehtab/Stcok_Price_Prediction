# MARS Regression Godrej Model 2013 Data 2013 #

# install.packages("earth")
library(earth)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv", header=TRUE)
attach(godrej_2013_reg)
godrej_2013_reg_mars <- earth(open_perc~., data = na.omit(godrej_2013_reg), trace = 1)
godrej_2013_reg_mars
summary(godrej_2013_reg_mars)
evimp(godrej_2013_reg_mars)
plot(godrej_2013_reg_mars)
plotmo(godrej_2013_reg_mars)

x <- predict(godrej_2013_reg_mars)
x
cor.test(godrej_2013_reg$open_perc, x)
cor(godrej_2013_reg$open_perc, x)

y <- godrej_2013_reg$open_perc
z <- x*y
which(z < 0)

library(Metrics)
a <- rmse(x,y)
a
b <- mean(abs(y))
b
w <- (a/b)*100
w

plot(y, xlab="Time points", ylab="Percentage change in Open value", lwd=2, lty=1, col="blue", type='l')
lines(x, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

plot(x~y, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)

plot(godrej_2013_reg_mars$residuals, xlab = "Time points", ylab = "Residual values", lwd = 2, xlim = c(0, 800))
