# MARS Regression Model Godrej Training 2013 Test 2014 #

# install.packages("earth")
library(earth)
godrej_2013_reg <- read.csv("godrej_2013_reg.csv", header=TRUE)
godrej_2014_reg <- read.csv("godrej_2014_reg.csv")
godrej_2014_reg <- godrej_2014_reg[,-5]
attach(godrej_2013_reg)
godrej_2013_reg_mars <- earth(open_perc~., data = na.omit(godrej_2013_reg), trace = 1)
godrej_2013_reg_mars
evimp(godrej_2013_reg_mars)
plot(godrej_2013_reg_mars)
plotmo(godrej_2013_reg_mars)
summary(godrej_2013_reg_mars)
x <- predict(godrej_2013_reg_mars, godrej_2014_reg)

actual <- scan("actual.txt")
predicted <- scan("predicted.txt")
cor.test(actual, predicted)

z <- actual*predicted
which(z < 0)

library(Metrics)
a <- rmse(actual,predicted)
a
b <- mean(abs(actual))
b
w <- (a/b)*100
w

plot(actual, xlab="Time points", ylab="Percentage change in Open value", lwd=2, lty=1, col="blue", type='l')
lines(predicted, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")

plot(predicted~actual, xlab = "Actual Index", ylab = "Predicted Index", lwd = 2)

plot(godrej_2013_reg_mars$residuals, xlab = "Time points", ylab = "Residual values", lwd = 2, xlim = c(0, 800))
