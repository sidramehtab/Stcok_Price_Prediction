# Bagging Classification Model Godrej Training 2013 Test 2013 #

library(ipred)
godrej_2013 <- read.csv("godrej_2013_cls.csv")
head(godrej_2013)
set.seed(300)
mybag <- bagging(open_perc~., data=godrej_2013, nbag=25)
open_pred <- predict(mybag, godrej_2013)
open_pred
attach(godrej_2013)
plot(godrej_2013$open_perc~open_pred, xlab = "Predicted percentage change in Open value", ylab = "Actual percentage change in Open value", lwd = 2)
gg1=floor(open_pred+0.5)
gg1

length(open_perc)
length(open_pred)
ttt <- table(open_perc,gg1)
ttt
length(gg1)
error <- (ttt[1,2]+ttt[2,1])/725
error
# for identifying the wronly predicted records
x <- (gg1 - open_perc)
which(x==1 | x==-1)
