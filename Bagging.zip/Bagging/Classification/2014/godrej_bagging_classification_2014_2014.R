# Bagging Classification using Godrej Model 2014 Data 2014 #

library(ipred)
godrej_2014 <- read.csv("godrej_2014_cls.csv")
head(godrej_2014)
set.seed(300)
mybag <- bagging(open_perc~., data=godrej_2014, nbag=25)
open_pred <- predict(mybag, godrej_2014)
open_pred
attach(godrej_2014)
plot(godrej_2014$open_perc~open_pred, xlab = "Predicted percentage change in Open value", ylab = "Actual percentage change in Open value", lwd = 2)
gg1=floor(open_pred+0.5)
gg1

length(open_perc)
length(open_pred)
ttt <- table(open_perc,gg1)
ttt
length(gg1)
error <- (ttt[1,2]+ttt[2,1])/725
error
# for identifying the wronly predicted records
x <- (gg1 - open_perc)
which(x==1 | x==-1)
